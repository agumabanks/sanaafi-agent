 import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/a_field_office/loans/controllers/LoanController.dart' as LoanController;
import 'package:six_cash/features/a_field_office/loans/controllers/loanController.dart';
import 'package:six_cash/features/a_field_office/loans/domain/loan_offermodal.dart';

class LoanApplicationPage extends StatefulWidget {
  @override
  _LoanApplicationPageState createState() => _LoanApplicationPageState();
}

class _LoanApplicationPageState extends State<LoanApplicationPage> {
   ClientLoanController controller = Get.put(ClientLoanController());
// Get.find<ClientLoanController>().fetchLoanOffers();


@override
  void initState() {
    super.initState();
    controller.fetchLoanOffers();
    // Get.find<AuthController>().getClients();
    // Get.find<AuthController>().getCustomerData();
    // Get.find<ClientLoanController>().fetchLoanOffers();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Loan Application'),
      ),
      body: Form(
        key: controller.formKey,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              DropdownButtonFormField<LoanOffer>(
                value: controller.selectedLoanOffer,
                hint: Text('Select Loan Offer'),
                items: controller.loanOffers.map((LoanOffer offer) {
                  return DropdownMenuItem<LoanOffer>(
                    value: offer,
                    child: Text(offer.planName),
                  );
                }).toList(),
                onChanged: (LoanOffer? value) {
                  setState(() {
                    controller.selectLoanOffer(value!);
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a loan offer';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: controller.loanAmountController,
                decoration: InputDecoration(labelText: 'Loan Amount'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a loan amount';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: controller.loanTermController,
                decoration: InputDecoration(labelText: 'Loan Term (months)'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a loan term';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              Text('Monthly Payment: ${controller.monthlyPayment.toStringAsFixed(2)}'),
              Text('Total Payment: ${controller.totalPayment.toStringAsFixed(2)}'),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (controller.formKey.currentState!.validate()) {
                    controller.submitLoanApplication();
                  }
                },
                child: Text('Submit Application'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}