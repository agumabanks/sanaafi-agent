// import 'package:Sanaa/features/auth/controllers/auth_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/auth/controllers/auth_controller.dart';
// import 'package:sanaa/features/auth/controllers/auth_controller.dart';
import '../domain/userLoan.dart';

class UserLoansScreen extends StatefulWidget {
  @override
  _UserLoansScreenState createState() => _UserLoansScreenState();
}

class _UserLoansScreenState extends State<UserLoansScreen> {
  @override
  void initState() {
    super.initState();
    Get.find<AuthController>().getUserLoans(isReload: true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
        title: Text('User Loans'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: () {
              // Reset user loans and refetch
              Get.find<AuthController>().resetUserLoans();
              setState(() {
                 Get.find<AuthController>().getUserLoans(isReload: true);
              });
            },
          ),
        ],
      ),
      body: GetBuilder<AuthController>(
        builder: (authController) {
          if (authController.userLoans == null) {
            return Center(child: CircularProgressIndicator());
          } else if (authController.userLoans!.isEmpty) {
            return const Center(child: Text('No loans found.'));
          }

          final loans = authController.userLoans!;
          return ListView.builder(
            itemCount: loans.length,
            itemBuilder: (context, index) {
              final loan = loans[index];
              return ListTile(
                title: Text('Loan ID: ${loan.id}'),
                subtitle: Text('Amount: ${loan.amount}'),
                trailing: Text('Status: ${loan.status}'),
              );
            },
          );
        },
      ),
    );
  }

  
}
