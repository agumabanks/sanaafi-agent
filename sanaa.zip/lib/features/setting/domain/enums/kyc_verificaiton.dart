enum KycVerification {
  approve,
  pending,
  denied,
  needApply,
}