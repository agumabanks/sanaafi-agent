import 'package:flutter/material.dart';

class PayLoanScreeen extends StatelessWidget {
  // const PayLoanScreeen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(child: Text("pay-loan")),
      ),
    );
  }
}