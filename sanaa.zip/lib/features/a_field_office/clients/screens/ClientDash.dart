import 'package:flutter/material.dart';

class ClientDash extends StatefulWidget {
  const ClientDash();

  @override
  State<ClientDash> createState() => _ClientDashState();
}

class _ClientDashState extends State<ClientDash> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        
      ),
    );
  }
}