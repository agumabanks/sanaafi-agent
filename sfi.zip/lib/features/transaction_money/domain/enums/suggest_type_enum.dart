enum SuggestType {
  sendMoney,
  cashOut,
  requestMoney
}